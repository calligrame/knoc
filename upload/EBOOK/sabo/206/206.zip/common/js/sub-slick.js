$(document).ready(function () {
  $(".sub-slide-container").slick({
    dots: true,
    autoplay: true,
    autoplaySpeed: 3000,
  });
});
